import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int sisa;

        System.out.println("Selamat datang di ");
        System.out.print("Masukan banyak obat: ");
        int banyakObat = input.nextInt();
        obat[] obat = new obat[banyakObat];

        // memasukan data tentang obat
        for (int i = 0; i < obat.length; i++) {
            System.out.println("masukan nama obat: ");
            String nama = input.next();
            System.out.println("masukan kategori obat: ");
            String kategori = input.next();
            System.out.println("masukan stok obat : ");
            int stok = input.nextInt();
            System.out.println("masukan jumlah yang terjual : ");
            int jumlah = input.nextInt();

            obat[i] = new obat(nama, kategori, stok, jumlah);
        }

        // menampilkan data tentang obat
        System.out.println("=================================");
        for (int i = 0; i < obat.length; i++) {
            System.out.println("Data obat ke-" + (i + 1));
            obat[i].tampil();
        }

        System.out.println("=================================");

        // menampilkan sisa tentang obat
        for (int i = 0; i < obat.length; i++) {
            sisa = obat[i].hitungSisa();
            System.out.println("Sisa obat ke-" + (i + 1) + " adalah : " + sisa);
            obat[i].stok = sisa;
        }

        // mencari obat paling laku
        System.out.println("=================================");

        int indeksLaku = 0;
        int jumlahLaku = obat[0].jumlah;

        for (int i = 1; i < obat.length; i++) {
            if (obat[i].jumlah > jumlahLaku) {
                jumlahLaku = obat[i].jumlah;
                indeksLaku = i;
            }
        }
        obat[indeksLaku].cariObatPalingLaku(jumlahLaku);

        int[] indeksObatlaku = new int[obat.length];

        for (int i = 0; i < indeksObatlaku.length; i++) {
            indeksObatlaku[i] = i;
        }

        System.out.println("=================================");

        // menampilkan data secara ascending dengan bubleshort
        for (int i = 0; i < obat.length - 1; i++) {
            for (int j = 0; j < obat.length - i - 1; j++) {
                if (obat[indeksObatlaku[j]].stok > obat[indeksObatlaku[j + 1]].stok) {
                    // Tukar posisi indeksObatlaku jika stoknya lebih besar
                    int temp = indeksObatlaku[j];
                    indeksObatlaku[j] = indeksObatlaku[j + 1];
                    indeksObatlaku[j + 1] = temp;
                }
            }
        }

        // Menampilkan daftar obat setelah diurutkan
        for (int i = 0; i < obat.length; i++) {
            obat[indeksObatlaku[i]].daftarObat();
        }

    }
}
