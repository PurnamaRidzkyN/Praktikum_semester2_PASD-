public class obat {

    public String nama;
    public String kategori;
    public int stok;
    public int jumlah;

    public obat() {

    }

    public obat(String nama, String kategori, int stok, int jumlah) {
        this.nama = nama;
        this.kategori = kategori;
        this.stok = stok;
        this.jumlah = jumlah;
    }

    void tampil() {
        System.out.println("Nama            : " + nama);
        System.out.println("Kategori        : " + kategori);
        System.out.println("Stok            : " + stok);
        System.out.println("Jumlah terjual  : " + jumlah);

    }

    int hitungSisa() {
        int sisa = stok - jumlah;
        return sisa;
    }

    void cariObatPalingLaku(int jumlah) {
        System.out.println("Data obat paling laku ");
        tampil();
    }

    void daftarObat() {

        System.out.println("Daftar oba sesuai stok ");
        tampil();
        System.out.println("=================================");

    }

}