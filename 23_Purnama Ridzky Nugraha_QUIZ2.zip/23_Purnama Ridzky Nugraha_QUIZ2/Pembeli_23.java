public class Pembeli_23 {
    String namaPembeli;
    String NoHp ;

    Pembeli_23(String namaPembeli, String NoHp){
        this.namaPembeli = namaPembeli;
        this.NoHp = NoHp;
    }
}
